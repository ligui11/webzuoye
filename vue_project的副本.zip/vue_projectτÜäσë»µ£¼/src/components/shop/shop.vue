<template>
  <div>
    <!-- 顶部快捷导航start -->
    <div class="shortcut">
      <div class="w">
        <div class="fl">
          <ul>
            <li>优购城欢迎您！</li>
            <li>
              <a href="javascript:;">请登录</a>
              <a href="javascript:;" class="style-red">免费注册</a>
            </li>
          </ul>
        </div>
        <div class="fr">
          <ul>
            <li>
              <a href="javascript:;">我的订单</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">我的优购城</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">优购城会员</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">企业采购</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">关注优购城</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">客户服务</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="javascript:;">网站导航</a>
              <i class="icomoon"></i>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 顶部快捷导航end  -->
    <!-- header制作 -->
    <div class="header w">
      <!-- logo -->
      <div class="logo">
        <img src="../../assets/img/logo.png" class="logo1" />
      </div>
      <!-- search -->
      <div class="search">
        <el-input
          placeholder="请输入内容"
          v-model="getListDataParams.query"
          clearable
          @clear="getListData"
        >
          <el-button slot="append" icon="el-icon-search" @click="getListData"></el-button>
        </el-input>
      </div>
      <!-- hotwrods -->
      <div class="shopcar" @click="goToCart">
        <i class="car"></i>我的购物车
        <i class="arrow"></i>
        <i class="count">{{this.$store.getters.totalItem}}</i>
      </div>
    </div>
    <!-- header 结束 -->
    <!-- nav start -->
    <div class="nav">
      <div class="w">
        <div class="dropdown fl"></div>
        <!-- 右侧导航 -->
        <div class="navitems fl"></div>
      </div>
    </div>
    <div class="main">
      <el-card class="goodsCard" v-for="(item, index) in goodsData" :key="item.goods_id" @click="goToDetail(item.goods_id)">
        <img :src="imgList[index]" @click="goToDetail(item.goods_id)"/>
        <p>{{item.goods_name}}</p>
        <p class="price">¥{{item.goods_price}}</p>
      </el-card>
      <!-- <el-card>
          <h2>商品列表</h2>
        <el-row>
          <el-table :data="goodsData" border style="width: 100%">
            <el-table-column type="index"></el-table-column>
            <el-table-column prop="goods_name" label="商品名称" width="auto"></el-table-column>
            <el-table-column prop="goods_price" label="商品价格" width="150px"></el-table-column>
            <el-table-column prop="goods_weight" label="商品重量(kg)" width="150px"></el-table-column>
            <el-table-column label="详情" width="120px">
              <template v-slot="scope">
                <el-button type="primary" size="mini" @click="goDetail(scope.row)">查看详情</el-button>
              </template>
            </el-table-column>
          </el-table>
      </el-row>-->
      <el-row>
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="getListDataParams.pagenum"
          :page-sizes="[3, 5, 10, 20]"
          :page-size="getListDataParams.pagesize"
          layout="total, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </el-row>
      <!-- </el-card> -->
    </div>
    <!-- nav end  -->
    <!-- main 模块 -->
    <!-- footer start -->
    <div class="footer">
      <div class="w">
        <!-- mod_service -->
        <div class="mod_service">
          <ul>
            <li>
              <i class="mod-service-icon mod_service_zheng"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_kuai"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
          </ul>
        </div>
        <!-- mod_help -->
        <div class="mod_help">
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item mod_help_app">
            <dt>帮助中心</dt>
            <dd>
              <img src="upload/erweima.png" alt />
              <p>优购城客户端</p>
            </dd>
          </dl>
        </div>

        <!-- mod_copyright  -->
        <div class="mod_copyright">
          <p
            class="mod_copyright_links"
          >关于我们 | 联系我们 | 联系客服 | 商家入驻 | 营销中心 | 手机优购城 | 友情链接 | 销售联盟 | 优购城社区 | 优购城公益 | English Site | Contact U</p>
          <p class="mod_copyright_info">
            地址：北京市昌平区建材城西路金燕龙办公楼一层 邮编：100096 电话：400-618-4000 传真：010-82935100 邮箱: zhanghj+itcast.cn
            <br />京ICP备08001421号京公网安备110108007702
          </p>
        </div>
      </div>
    </div>
    <!-- footer end -->
  </div>
</template>

<script>
import '../../assets/css/base.css'
import '../../assets/css/common.css'
import '../../assets/css/index.css'
// import { mapState } from 'vuex'
export default {
  data() {
    return {
      getListDataParams: {
        query: '',
        pagenum: 1,
        pagesize: 9
      },
      goodsData: [],
      total: 0,
      imgList: []
    }
  },
  created() {
    this.getListData()
  },
  methods: {
    goToCart: function() {
      this.$router.push('/cart')
    },
    goDetail: function(row) {
      console.log(row)
      this.$router.push({
        path: `/detail/${row.goods_id}`
      })
    },
    getListData: async function() {
      const { data } = await this.$http.get('goods', {
        params: this.getListDataParams
      })
      // console.log(data)
      if (data.meta.status !== 200) {
        return this.$message.info('get list data failed')
      }
      this.goodsData = data.data.goods
      await this.eachGoodsId()
      // console.log(this.goodsData)
      this.total = data.data.total
    },
    handleSizeChange: function(size) {
      // console.log(size)
      this.getListDataParams.pagesize = size
      this.getListData()
    },
    handleCurrentChange: function(page) {
      // console.log(page)
      this.getListDataParams.pagenum = page
      this.getListData()
    },
    goAddItemPage: function() {
      this.$router.push('goods/add')
    },
    eachGoodsId: async function() {
      this.imgList = []
      // this.goodsData.forEach(async item => {
      //   await this.pushImgList(item.goods_id)
      // })
      console.log(this.goodsData)
      for (let i = 0; i < this.goodsData.length; i++) {
        await this.pushImgList(this.goodsData[i].goods_id)
      }
    },
    pushImgList: async function(id) {
      // console.log(this.goodsData)
      const { data } = await this.$http.get(`goods/${id}`)
      this.imgList.push(data.data.pics[0].pics_big_url || '') // 返回图片地址添加到图片数组
    },
    goToDetail: function(id) {
      console.log('ha')
      this.$router.push(`detail/${id}`)
    }
  }
}
</script>

<style lang='less'>
.nav {
  height: 5px;
}
.goodsCard {
  position: relative;
  width: 300px;
  height: 350px;
  margin-bottom: 20px;
  img {
    &:hover {
      cursor: pointer;
    }
    width: 220px;
    height: 250px;
    margin-left: 20px;
    box-sizing: content-box;
  }
  .price {
    position: absolute;
    right: 10px;
    bottom: 10px;
  }
}
.main {
  transform: translateX(-100px);
  height: 1200px;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
}
</style>