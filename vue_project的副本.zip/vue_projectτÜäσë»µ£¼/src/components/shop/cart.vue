<template>
  <div>
    <div class="shortcut">
      <div class="w">
        <div class="fl">
          <ul>
            <li>优购城欢迎您！</li>
            <li>
              <a href="#">请登录</a>
              <a href="#" class="style-red">免费注册</a>
            </li>
          </ul>
        </div>
        <div class="fr">
          <ul>
            <li>
              <a href="#">我的订单</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">我的优购城</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">优购城会员</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">企业采购</a>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">关注优购城</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">客户服务</a>
              <i class="icomoon"></i>
            </li>
            <li class="spacer"></li>
            <li>
              <a href="#">网站导航</a>
              <i class="icomoon"></i>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="car-header">
      <div class="w">
        <div class="car-logo">
        <img src="../../assets/img/logo.png" class="logo1" @click="goShop">
          <b>购物车</b>
        </div>
      </div>
    </div>
    <div class="c-container">
      <div class="w">
        <div class="cart-filter-bar">
          <em>全部商品</em>
        </div>
        <!-- 购物车主要核心区域 -->
        <div class="cart-warp">
          <!-- 头部全选模块 -->
          <!-- 商品详细模块 -->
          <div class="cart-item-list">
            <el-table
              ref="multipleTable"
              :data="items"
              tooltip-effect="dark"
              style="width: 100%"
            >
              <!-- <el-table-column type="selection" width="55"></el-table-column> -->
              <el-table-column prop="pic" label="商品" width="120">
                  <template v-slot="scope">
                      <img :src="scope.row.pic" class="itemimg">
                  </template>
              </el-table-column>
              <el-table-column prop="name" label="名称" width="550"></el-table-column>
              <el-table-column prop="price" label="单价" width="250"></el-table-column>
              <el-table-column prop="num" label="数量" width="250"></el-table-column>
            </el-table>
          </div>

          <!-- 结算模块 -->
          <div class="cart-floatbar">
            <div class="toolbar-right">
              <div class="amount-sum">
                已经选
                <em>{{this.$store.getters.totalItem}}</em>件商品
              </div>
              <div class="price-sum">
                总价：
                <em>{{this.$store.getters.sum}}</em>
              </div>
              <div class="btn-area">去结算</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <div class="w">
        <!-- mod_service -->
        <div class="mod_service">
          <ul>
            <li>
              <i class="mod-service-icon mod_service_zheng"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_kuai"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
            <li>
              <i class="mod-service-icon mod_service_bao"></i>
              <div class="mod_service_tit">
                <h5>正品保障</h5>
                <p>正品保障，提供发票</p>
              </div>
            </li>
          </ul>
        </div>
        <!-- mod_help -->
        <div class="mod_help">
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item">
            <dt>购物指南</dt>
            <dd>
              <a href="#">购物流程</a>
            </dd>
            <dd>
              <a href="#">会员介绍</a>
            </dd>
            <dd>
              <a href="#">生活旅行/团购</a>
            </dd>
            <dd>
              <a href="#">常见问题</a>
            </dd>
            <dd>
              <a href="#">大家电</a>
            </dd>
            <dd>
              <a href="#">联系客服</a>
            </dd>
          </dl>
          <dl class="mod_help_item mod_help_app">
            <dt>帮助中心</dt>
            <dd>
              <img src="upload/erweima.png" alt />
              <p>优购城客户端</p>
            </dd>
          </dl>
        </div>

        <!-- mod_copyright  -->
        <div class="mod_copyright">
          <p
            class="mod_copyright_links"
          >关于我们 | 联系我们 | 联系客服 | 商家入驻 | 营销中心 | 手机优购城 | 友情链接 | 销售联盟 | 优购城社区 | 优购城公益 | English Site | Contact U</p>
          <p class="mod_copyright_info">
            地址：北京市昌平区建材城西路金燕龙办公楼一层 邮编：100096 电话：400-618-4000 传真：010-82935100 邮箱: zhanghj+itcast.cn
            <br />京ICP备08001421号京公网安备110108007702
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import '../../assets/css/base.css'
import '../../assets/css/common.css'
import '../../assets/css/car.css'
import { mapState } from 'vuex'
export default {
  data() {
    return {
      checkAll: false,
      checkedCities: ['上海', '北京']
    }
  },
  computed: {
    ...mapState(['items'])
  },
  created() {
      console.log(this.items)
  },
  methods: {
    goShop: function() {
      this.$router.push('shop')
    }
  }
}
</script>
<style lang='less'>
.itemimg {
    height: 100px;
    width: 100px;
}
</style>