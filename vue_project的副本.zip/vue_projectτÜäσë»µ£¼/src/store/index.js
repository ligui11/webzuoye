import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    items: []
  },
  mutations: {
    add: function(state, step) {
      state.items.push(step)
    }
  },
  actions: {
  },
  getters: {
    totalItem: function(state) {
      let total = 0
      state.items.forEach(item => {
        total += item.num
      })
      return total
    },
    sum: function(state) {
      let sum = 0
      state.items.forEach(item => {
        sum += item.num * item.price
      })
      return sum
    }
  },
  modules: {
  }
})
